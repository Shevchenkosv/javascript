'use strict';
const products = [
    new ProductDTO(
        0,
        'Product 1',
        52.00,
    ),
    new ProductDTO(
        1,
        'Product 2',
        52.00,
    ),
    new ProductDTO(
        2,
        'Product 3',
        52.00,
    ),
    new ProductDTO(
        3,
        'Product 4',
        52.00,
    ),
    new ProductDTO(
        4,
        'Product 5',
        52.00,
    ),
    new ProductDTO(
        5,
        'Product 6',
        52.00,
    ),
    new ProductDTO(
        6,
        'Product 7',
        52.00,
    ),
    new ProductDTO(
        7,
        'Product 8',
        52.00,
    ),
    new ProductDTO(
        8,
        'Product 9',
        52.00,
    ),
];